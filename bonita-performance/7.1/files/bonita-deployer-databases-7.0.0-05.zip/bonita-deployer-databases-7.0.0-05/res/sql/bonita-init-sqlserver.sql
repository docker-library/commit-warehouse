-- Drop database if exists
IF EXISTS (SELECT name FROM master.dbo.sysdatabases WHERE name = N'@db_name@')
BEGIN
  ALTER DATABASE [@db_name@] SET OFFLINE WITH ROLLBACK IMMEDIATE;
  ALTER DATABASE [@db_name@] SET ONLINE;
  DROP DATABASE [@db_name@];
END
GO

-- Create database
CREATE DATABASE [@db_name@];
GO

-- Enable Row Versioning-Based Isolation Levels
ALTER DATABASE @db_name@ SET ALLOW_SNAPSHOT_ISOLATION ON;
GO

ALTER DATABASE @db_name@ SET READ_COMMITTED_SNAPSHOT ON;
GO

-- Use created database
USE [@db_name@];
GO

-- Create login if not exists
IF NOT EXISTS (SELECT name FROM sys.server_principals WHERE name = '@db_user@')
BEGIN
  CREATE LOGIN @db_user@ WITH PASSWORD = '@db_password@', CHECK_POLICY = OFF;
END
GO

-- Create user if not exists
IF NOT EXISTS (SELECT name FROM sys.database_principals WHERE name = '@db_user@')
BEGIN
  CREATE USER @db_user@ FOR LOGIN @db_user@;
END
GO

-- Grant permissions
EXEC sp_addrolemember N'db_datareader', N'@db_user@';
EXEC sp_addrolemember N'db_datawriter', N'@db_user@';
EXEC sp_addrolemember N'db_ddladmin', N'@db_user@';
GO

--
-- Supporting XA transactions
--
-- Use master database
USE master;
GO

-- Create login if not exists
IF NOT EXISTS (SELECT name FROM sys.server_principals WHERE name = '@db_user@')
BEGIN
  CREATE LOGIN @db_user@ WITH PASSWORD = '@db_password@', CHECK_POLICY = OFF;
END
GO

-- Create user if not exists
IF NOT EXISTS (SELECT name FROM sys.database_principals WHERE name = '@db_user@')
BEGIN
  CREATE USER @db_user@ FOR LOGIN @db_user@;
END
GO

-- Grant XA permissions
EXEC sp_addrolemember [SqlJDBCXAUser], '@db_user@';
GO
