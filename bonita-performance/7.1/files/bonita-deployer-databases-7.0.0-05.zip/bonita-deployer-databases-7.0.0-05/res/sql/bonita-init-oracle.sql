declare
  v_count number;
  v_banner varchar2(50) := 'Oracle Database 12c%';
  v_tsusers_quota number;

  cursor c1 is
    select s.sid, s.serial#, s.username from gv$session s
    where s.type != 'BACKGROUND' and upper(s.username) = upper('@db_user@');

  cursor c2 is
    select v.banner from v$version v;

begin
  -- disconnect sessions
  for session_rec in c1
  loop
    execute immediate 'ALTER SYSTEM DISCONNECT SESSION '''||session_rec.sid||','||session_rec.serial#||''' IMMEDIATE';
  end loop;

  -- for oracle 12c
  for cur_banner in c2 loop
    if cur_banner.banner LIKE v_banner
    then
      execute immediate 'alter session set "_ORACLE_SCRIPT"=true';
    end if;
  end loop;

  -- drop user
  select count(1) into v_count from dba_users where upper(username) = upper('@db_user@');
  if v_count != 0 and 'Ydrop_existing' = '@drop_existing@drop_existing'
  then
    execute immediate 'drop user @db_user@ cascade';
  end if;

  -- create user
  select count(1) into v_count from dba_users where upper(username) = upper('@db_user@');
  if v_count = 0
  then
    execute immediate 'CREATE USER @db_user@ IDENTIFIED BY @db_password@';
  end if;
  select round(0.8*bytes/1024/1024) into v_tsusers_quota from dba_data_files where TABLESPACE_NAME = 'USERS';
  execute immediate 'ALTER USER @db_user@ QUOTA ' || v_tsusers_quota || 'M ON USERS';
  execute immediate 'GRANT connect, resource TO @db_user@';
  execute immediate 'GRANT select ON sys.dba_pending_transactions TO @db_user@';
  execute immediate 'GRANT select ON sys.pending_trans$ TO @db_user@';
  execute immediate 'GRANT select ON sys.dba_2pc_pending TO @db_user@';
  execute immediate 'GRANT execute ON sys.dbms_system TO @db_user@';
end;
