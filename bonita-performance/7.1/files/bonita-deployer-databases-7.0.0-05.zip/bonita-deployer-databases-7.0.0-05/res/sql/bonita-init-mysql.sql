DROP DATABASE IF EXISTS `@db_name@`;

CREATE DATABASE `@db_name@` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;

GRANT ALL PRIVILEGES ON `@db_name@`.* TO '@db_user@'@'%' identified BY '@db_password@';

GRANT ALL PRIVILEGES ON `@db_name@`.* TO '@db_user@'@'localhost' identified BY '@db_password@';
